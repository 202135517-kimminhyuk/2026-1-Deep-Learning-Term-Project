const SIZE = 19;
const EMPTY = 0;
const BLACK = 1;
const WHITE = -1;

const canvas = document.getElementById("board");
const ctx = canvas.getContext("2d");
const startBtn = document.getElementById("startBtn");
const resetBtn = document.getElementById("resetBtn");
const statusEl = document.getElementById("status");
const recommendationsEl = document.getElementById("recommendations");
const moveLogEl = document.getElementById("moveLog");

let board = createBoard();
let current = BLACK;
let started = false;
let hoverPoint = null;
let recommendations = [];
let moveNumber = 0;
let modelApiAvailable = true;

function createBoard() {
  return Array.from({ length: SIZE }, () => Array(SIZE).fill(EMPTY));
}

function pointToLabel(row, col) {
  const letters = "ABCDEFGHJKLMNOPQRST";
  return `${letters[col]}${SIZE - row}`;
}

function colorName(color) {
  return color === BLACK ? "Black" : "White";
}

function geometry() {
  const w = canvas.width;
  const margin = w * 0.07;
  const step = (w - margin * 2) / (SIZE - 1);
  return { margin, step };
}

function boardToCanvas(row, col) {
  const { margin, step } = geometry();
  return {
    x: margin + col * step,
    y: margin + row * step,
  };
}

function canvasToBoard(event) {
  const rect = canvas.getBoundingClientRect();
  const scaleX = canvas.width / rect.width;
  const scaleY = canvas.height / rect.height;
  const x = (event.clientX - rect.left) * scaleX;
  const y = (event.clientY - rect.top) * scaleY;
  const { margin, step } = geometry();
  const col = Math.round((x - margin) / step);
  const row = Math.round((y - margin) / step);

  if (row < 0 || row >= SIZE || col < 0 || col >= SIZE) return null;

  const snapped = boardToCanvas(row, col);
  const distance = Math.hypot(snapped.x - x, snapped.y - y);
  if (distance > step * 0.45) return null;
  return { row, col };
}

function neighbors(row, col) {
  const result = [];
  if (row > 0) result.push([row - 1, col]);
  if (row + 1 < SIZE) result.push([row + 1, col]);
  if (col > 0) result.push([row, col - 1]);
  if (col + 1 < SIZE) result.push([row, col + 1]);
  return result;
}

function getGroup(grid, row, col) {
  const color = grid[row][col];
  const stack = [[row, col]];
  const seen = new Set();
  const stones = [];
  const liberties = new Set();

  while (stack.length) {
    const [r, c] = stack.pop();
    const key = `${r},${c}`;
    if (seen.has(key)) continue;
    seen.add(key);
    stones.push([r, c]);

    for (const [nr, nc] of neighbors(r, c)) {
      const value = grid[nr][nc];
      if (value === EMPTY) liberties.add(`${nr},${nc}`);
      if (value === color && !seen.has(`${nr},${nc}`)) stack.push([nr, nc]);
    }
  }

  return { stones, liberties };
}

function cloneBoard(grid) {
  return grid.map((row) => row.slice());
}

function tryMove(grid, row, col, color) {
  if (grid[row][col] !== EMPTY) return null;

  const next = cloneBoard(grid);
  next[row][col] = color;
  const opponent = -color;

  for (const [nr, nc] of neighbors(row, col)) {
    if (next[nr][nc] !== opponent) continue;
    const group = getGroup(next, nr, nc);
    if (group.liberties.size === 0) {
      for (const [sr, sc] of group.stones) next[sr][sc] = EMPTY;
    }
  }

  const ownGroup = getGroup(next, row, col);
  if (ownGroup.liberties.size === 0) return null;
  return next;
}

function placeMove(row, col) {
  if (!started) return;
  const next = tryMove(board, row, col, current);
  if (!next) return;

  board = next;
  moveNumber += 1;
  const li = document.createElement("li");
  li.textContent = `${colorName(current)} ${pointToLabel(row, col)}`;
  moveLogEl.prepend(li);
  current = -current;
  hoverPoint = null;
  updateRecommendations();
  draw();
}

function scorePoint(row, col, color) {
  if (!tryMove(board, row, col, color)) return -Infinity;

  const center = Math.hypot(row - 9, col - 9);
  let score = 100 - center * 2;
  const starPoints = [3, 9, 15];
  if (starPoints.includes(row) && starPoints.includes(col)) score += 18;

  for (const [nr, nc] of neighbors(row, col)) {
    if (board[nr][nc] === color) score += 14;
    if (board[nr][nc] === -color) score += 10;
  }

  const simulated = tryMove(board, row, col, color);
  let captures = 0;
  if (simulated) {
    for (let r = 0; r < SIZE; r++) {
      for (let c = 0; c < SIZE; c++) {
        if (board[r][c] === -color && simulated[r][c] === EMPTY) captures += 1;
      }
    }
  }
  score += captures * 25;

  score += Math.random() * 0.01;
  return score;
}

async function fetchModelRecommendations() {
  const payload = {
    board,
    current,
  };

  const response = await fetch("/api/recommend", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });

  if (!response.ok) throw new Error("recommendation API failed");
  const data = await response.json();
  return data.moves;
}

function getFallbackRecommendations() {
  const moves = [];
  for (let row = 0; row < SIZE; row++) {
    for (let col = 0; col < SIZE; col++) {
      const score = scorePoint(row, col, current);
      if (Number.isFinite(score)) moves.push({ row, col, score });
    }
  }
  moves.sort((a, b) => b.score - a.score);
  return moves.slice(0, 5);
}

async function updateRecommendations() {
  recommendations = [];
  if (!started) {
    renderRecommendations();
    return;
  }

  try {
    recommendations = await fetchModelRecommendations();
    modelApiAvailable = true;
  } catch (error) {
    recommendations = getFallbackRecommendations();
    modelApiAvailable = false;
  }

  renderRecommendations();
  const source = modelApiAvailable ? "model" : "fallback";
  statusEl.textContent = `${colorName(current)} to move. Top-5 source: ${source}.`;
}

function renderRecommendations() {
  recommendationsEl.innerHTML = "";
  if (!started) {
    recommendationsEl.innerHTML = "<p>Start a game to show suggested moves.</p>";
    return;
  }

  recommendations.forEach((move, index) => {
    const button = document.createElement("button");
    button.className = "recommendation";
    button.type = "button";
    button.innerHTML = `
      <span class="rank">#${index + 1}</span>
      <span>${pointToLabel(move.row, move.col)}</span>
      <span class="score">${move.score.toFixed(1)}</span>
    `;
    button.addEventListener("click", () => placeMove(move.row, move.col));
    recommendationsEl.appendChild(button);
  });
}

function drawBoard() {
  const { margin, step } = geometry();
  ctx.fillStyle = "#d9a85f";
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  ctx.strokeStyle = "#2b2117";
  ctx.lineWidth = 1.5;
  for (let i = 0; i < SIZE; i++) {
    const p = margin + i * step;
    ctx.beginPath();
    ctx.moveTo(margin, p);
    ctx.lineTo(canvas.width - margin, p);
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(p, margin);
    ctx.lineTo(p, canvas.height - margin);
    ctx.stroke();
  }

  ctx.fillStyle = "#2b2117";
  for (const r of [3, 9, 15]) {
    for (const c of [3, 9, 15]) {
      const { x, y } = boardToCanvas(r, c);
      ctx.beginPath();
      ctx.arc(x, y, 4.5, 0, Math.PI * 2);
      ctx.fill();
    }
  }
}

function drawStone(row, col, color, alpha = 1) {
  const { step } = geometry();
  const { x, y } = boardToCanvas(row, col);
  const radius = step * 0.42;
  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.beginPath();
  ctx.arc(x, y, radius, 0, Math.PI * 2);
  ctx.fillStyle = color === BLACK ? "#111111" : "#f4f0e8";
  ctx.fill();
  ctx.strokeStyle = color === BLACK ? "#000000" : "#a79f93";
  ctx.lineWidth = 1.5;
  ctx.stroke();
  ctx.restore();
}

function drawRecommendations() {
  recommendations.forEach((move, index) => {
    const { x, y } = boardToCanvas(move.row, move.col);
    ctx.save();
    ctx.fillStyle = "rgba(23, 107, 135, 0.86)";
    ctx.beginPath();
    ctx.arc(x, y, 12, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#ffffff";
    ctx.font = "bold 13px Arial";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(String(index + 1), x, y + 0.5);
    ctx.restore();
  });
}

function draw() {
  drawBoard();
  drawRecommendations();
  for (let row = 0; row < SIZE; row++) {
    for (let col = 0; col < SIZE; col++) {
      if (board[row][col] !== EMPTY) drawStone(row, col, board[row][col]);
    }
  }

  if (started && hoverPoint && board[hoverPoint.row][hoverPoint.col] === EMPTY) {
    if (tryMove(board, hoverPoint.row, hoverPoint.col, current)) {
      drawStone(hoverPoint.row, hoverPoint.col, current, 0.42);
    }
  }
}

function startGame() {
  board = createBoard();
  current = BLACK;
  started = true;
  hoverPoint = null;
  moveNumber = 0;
  moveLogEl.innerHTML = "";
  updateRecommendations();
  draw();
}

canvas.addEventListener("mousemove", (event) => {
  hoverPoint = canvasToBoard(event);
  draw();
});

canvas.addEventListener("mouseleave", () => {
  hoverPoint = null;
  draw();
});

canvas.addEventListener("click", (event) => {
  const point = canvasToBoard(event);
  if (point) placeMove(point.row, point.col);
});

startBtn.addEventListener("click", startGame);
resetBtn.addEventListener("click", startGame);

renderRecommendations();
draw();
