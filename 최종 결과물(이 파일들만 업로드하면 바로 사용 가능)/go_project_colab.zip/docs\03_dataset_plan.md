# Dataset Plan

## What the Project Needs

The project needs Go game records in SGF format.

Preferred input:

```text
data/raw/*.sgf
```

or an archive such as:

```text
data/raw/go_games.zip
data/raw/go_games.tar.gz
```

Each SGF file should contain a 19x19 Go game. The parser will extract board states and next-move labels from these records.

## Recommended Public Dataset

### Option 1: Joe's Go Database

Joe's Go Database is the best first choice for this project.

Reasons:

- It contains more than 500,000 games.
- The games are already in SGF format.
- It is split into training, validation, and test sets.
- It was created for machine learning projects.
- The dataset is released into the public domain by the maintainer.

For this term project, we do not need to train on the full dataset. A small subset such as 1,000 to 10,000 games is enough for initial experiments.

### Option 2: Japanese Professional SGF Archive

This archive contains more than 90,000 professional games in SGF format.

Reasons:

- Smaller download than Joe's Go Database.
- Professional game quality is high.
- Good enough for a compact term project experiment.

Possible downside:

- The archive may include unusual board sizes, so the parser must filter only 19x19 games.

Current project status:

- This archive has been downloaded to `data/raw/cwi_go_games.tgz`.
- It has been extracted to `data/raw/cwi_go_games/games/`.
- The current extracted SGF count is about 95,000 games.

### Option 3: OGS Public Game Collection

The OGS collection is very large and useful for research, but it is too large for the first version of this project.

It may be useful only if we choose a small sample file.

## Initial Dataset Scope

For the first working version, use:

- 500 to 2,000 SGF games for quick debugging
- 5,000 to 10,000 SGF games for final experiments if training time allows

From each game, the dataset builder will generate many training samples:

```text
one board position -> next move label
```

If one game has 200 moves, then 1,000 games can create roughly 200,000 training samples before filtering.

## Data Split

The prepared samples will be split into:

- Train: 80%
- Validation: 10%
- Test: 10%

If the source dataset already has train/validation/test folders, we will preserve that split.

## Filtering Rules

The first parser version will:

- keep only 19x19 games
- skip pass moves
- skip setup stones or unusual rules if they complicate parsing
- skip malformed SGF files
- ignore branches and variations

## Data Augmentation

Go board symmetries can increase the dataset size without changing the meaning of a position.

The project will test:

- no augmentation
- random rotation and flip augmentation

This gives a clean experiment for the report.
