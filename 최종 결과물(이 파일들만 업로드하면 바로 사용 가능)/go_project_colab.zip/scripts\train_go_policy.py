import argparse
import csv
import json
import random
from pathlib import Path

import numpy as np
import torch
from torch import nn
from torch.utils.data import DataLoader, Dataset


BOARD_SIZE = 19
NUM_MOVES = BOARD_SIZE * BOARD_SIZE


def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def split_indices(num_items, val_ratio, test_ratio, seed):
    rng = np.random.default_rng(seed)
    indices = rng.permutation(num_items)
    test_size = int(num_items * test_ratio)
    val_size = int(num_items * val_ratio)
    test_idx = indices[:test_size]
    val_idx = indices[test_size : test_size + val_size]
    train_idx = indices[test_size + val_size :]
    return train_idx, val_idx, test_idx


def transform_label(label, transform_id):
    row = label // BOARD_SIZE
    col = label % BOARD_SIZE
    k = transform_id % 4

    if k == 1:
        row, col = BOARD_SIZE - 1 - col, row
    elif k == 2:
        row, col = BOARD_SIZE - 1 - row, BOARD_SIZE - 1 - col
    elif k == 3:
        row, col = col, BOARD_SIZE - 1 - row

    if transform_id >= 4:
        col = BOARD_SIZE - 1 - col

    return row * BOARD_SIZE + col


def transform_board(board, transform_id):
    k = transform_id % 4
    if k:
        board = torch.rot90(board, k=k, dims=(1, 2))
    if transform_id >= 4:
        board = torch.flip(board, dims=(2,))
    return board


class GoMoveDataset(Dataset):
    def __init__(self, x, y, indices, augment=False):
        self.x = x
        self.y = y
        self.indices = indices
        self.augment = augment

    def __len__(self):
        return len(self.indices)

    def __getitem__(self, idx):
        data_idx = self.indices[idx]
        board = torch.from_numpy(self.x[data_idx]).float()
        label = int(self.y[data_idx])

        if self.augment:
            transform_id = random.randint(0, 7)
            board = transform_board(board, transform_id)
            label = transform_label(label, transform_id)

        return board, torch.tensor(label, dtype=torch.long)


class BaselineCNN(nn.Module):
    def __init__(self, channels=64, dropout=0.0):
        super().__init__()
        self.features = nn.Sequential(
            nn.Conv2d(4, channels, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(channels, channels, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(channels, channels, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(channels),
            nn.ReLU(inplace=True),
            nn.Dropout2d(dropout),
        )
        self.classifier = nn.Linear(channels * BOARD_SIZE * BOARD_SIZE, NUM_MOVES)

    def forward(self, x):
        x = self.features(x)
        x = torch.flatten(x, 1)
        return self.classifier(x)


class ResidualBlock(nn.Module):
    def __init__(self, channels):
        super().__init__()
        self.layers = nn.Sequential(
            nn.Conv2d(channels, channels, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(channels, channels, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(channels),
        )
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        return self.relu(x + self.layers(x))


class ResidualPolicyNet(nn.Module):
    def __init__(self, channels=64, blocks=4, dropout=0.0):
        super().__init__()
        self.stem = nn.Sequential(
            nn.Conv2d(4, channels, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(channels),
            nn.ReLU(inplace=True),
        )
        self.res_blocks = nn.Sequential(*[ResidualBlock(channels) for _ in range(blocks)])
        self.policy_head = nn.Sequential(
            nn.Conv2d(channels, 2, kernel_size=1, bias=False),
            nn.BatchNorm2d(2),
            nn.ReLU(inplace=True),
            nn.Dropout2d(dropout),
        )
        self.classifier = nn.Linear(2 * BOARD_SIZE * BOARD_SIZE, NUM_MOVES)

    def forward(self, x):
        x = self.stem(x)
        x = self.res_blocks(x)
        x = self.policy_head(x)
        x = torch.flatten(x, 1)
        return self.classifier(x)


def build_model(args):
    if args.model == "baseline":
        return BaselineCNN(channels=args.channels, dropout=args.dropout)
    if args.model == "resnet":
        return ResidualPolicyNet(channels=args.channels, blocks=args.blocks, dropout=args.dropout)
    raise ValueError(f"Unknown model: {args.model}")


def topk_correct(logits, targets, k):
    _, pred = logits.topk(k, dim=1)
    return pred.eq(targets.view(-1, 1)).any(dim=1).sum().item()


def run_epoch(model, loader, criterion, device, optimizer=None):
    is_train = optimizer is not None
    model.train(is_train)
    total_loss = 0.0
    total = 0
    top1 = 0
    top5 = 0

    for boards, labels in loader:
        boards = boards.to(device, non_blocking=True)
        labels = labels.to(device, non_blocking=True)

        with torch.set_grad_enabled(is_train):
            logits = model(boards)
            loss = criterion(logits, labels)

            if is_train:
                optimizer.zero_grad(set_to_none=True)
                loss.backward()
                optimizer.step()

        batch_size = labels.size(0)
        total_loss += loss.item() * batch_size
        total += batch_size
        top1 += topk_correct(logits, labels, 1)
        top5 += topk_correct(logits, labels, 5)

    return {
        "loss": total_loss / max(total, 1),
        "top1": top1 / max(total, 1),
        "top5": top5 / max(total, 1),
    }


def save_history(history, output_dir):
    csv_path = output_dir / "history.csv"
    with csv_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=[
                "epoch",
                "train_loss",
                "train_top1",
                "train_top5",
                "val_loss",
                "val_top1",
                "val_top5",
            ],
        )
        writer.writeheader()
        writer.writerows(history)

    try:
        import matplotlib.pyplot as plt

        epochs = [row["epoch"] for row in history]

        plt.figure(figsize=(8, 5))
        plt.plot(epochs, [row["train_loss"] for row in history], label="train")
        plt.plot(epochs, [row["val_loss"] for row in history], label="validation")
        plt.xlabel("Epoch")
        plt.ylabel("Loss")
        plt.title("Training and Validation Loss")
        plt.legend()
        plt.tight_layout()
        plt.savefig(output_dir / "loss_curve.png", dpi=160)
        plt.close()

        plt.figure(figsize=(8, 5))
        plt.plot(epochs, [row["train_top1"] for row in history], label="train top-1")
        plt.plot(epochs, [row["val_top1"] for row in history], label="val top-1")
        plt.plot(epochs, [row["train_top5"] for row in history], label="train top-5")
        plt.plot(epochs, [row["val_top5"] for row in history], label="val top-5")
        plt.xlabel("Epoch")
        plt.ylabel("Accuracy")
        plt.title("Top-k Accuracy")
        plt.legend()
        plt.tight_layout()
        plt.savefig(output_dir / "accuracy_curve.png", dpi=160)
        plt.close()
    except ImportError:
        print("matplotlib is not installed; skipped graph generation.")


def save_prediction_heatmap(model, dataset, output_dir, device):
    try:
        import matplotlib.pyplot as plt
    except ImportError:
        return

    model.eval()
    board, label = dataset[0]
    with torch.no_grad():
        logits = model(board.unsqueeze(0).to(device))
        probs = torch.softmax(logits, dim=1).cpu().numpy()[0].reshape(BOARD_SIZE, BOARD_SIZE)

    true_row = int(label) // BOARD_SIZE
    true_col = int(label) % BOARD_SIZE

    plt.figure(figsize=(6, 5))
    plt.imshow(probs, cmap="viridis")
    plt.scatter([true_col], [true_row], c="red", s=50, marker="x", label="actual move")
    plt.colorbar(label="Predicted probability")
    plt.title("Predicted Next-Move Heatmap")
    plt.legend()
    plt.tight_layout()
    plt.savefig(output_dir / "prediction_heatmap.png", dpi=160)
    plt.close()


def main():
    parser = argparse.ArgumentParser(description="Train a Go next-move policy model.")
    parser.add_argument("--data", required=True, help="Prepared .npz dataset file.")
    parser.add_argument("--output-dir", default="outputs/resnet_run")
    parser.add_argument("--model", choices=["baseline", "resnet"], default="resnet")
    parser.add_argument("--epochs", type=int, default=5)
    parser.add_argument("--batch-size", type=int, default=256)
    parser.add_argument("--lr", type=float, default=3e-4)
    parser.add_argument("--weight-decay", type=float, default=1e-4)
    parser.add_argument("--channels", type=int, default=64)
    parser.add_argument("--blocks", type=int, default=4)
    parser.add_argument("--dropout", type=float, default=0.0)
    parser.add_argument("--augment", action="store_true")
    parser.add_argument("--val-ratio", type=float, default=0.1)
    parser.add_argument("--test-ratio", type=float, default=0.1)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--num-workers", type=int, default=2)
    args = parser.parse_args()

    set_seed(args.seed)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    raw = np.load(args.data)
    x = raw["x"]
    y = raw["y"]
    train_idx, val_idx, test_idx = split_indices(len(y), args.val_ratio, args.test_ratio, args.seed)

    train_ds = GoMoveDataset(x, y, train_idx, augment=args.augment)
    val_ds = GoMoveDataset(x, y, val_idx, augment=False)
    test_ds = GoMoveDataset(x, y, test_idx, augment=False)

    pin_memory = torch.cuda.is_available()
    train_loader = DataLoader(
        train_ds,
        batch_size=args.batch_size,
        shuffle=True,
        num_workers=args.num_workers,
        pin_memory=pin_memory,
    )
    val_loader = DataLoader(
        val_ds,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=args.num_workers,
        pin_memory=pin_memory,
    )
    test_loader = DataLoader(
        test_ds,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=args.num_workers,
        pin_memory=pin_memory,
    )

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = build_model(args).to(device)
    criterion = nn.CrossEntropyLoss()
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)

    metadata = vars(args).copy()
    metadata.update(
        {
            "device": str(device),
            "num_positions": int(len(y)),
            "train_size": int(len(train_idx)),
            "val_size": int(len(val_idx)),
            "test_size": int(len(test_idx)),
            "model_parameters": int(sum(p.numel() for p in model.parameters())),
        }
    )
    (output_dir / "config.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")

    history = []
    best_val_loss = float("inf")
    best_path = output_dir / "best_model.pt"

    for epoch in range(1, args.epochs + 1):
        train_metrics = run_epoch(model, train_loader, criterion, device, optimizer)
        val_metrics = run_epoch(model, val_loader, criterion, device)

        row = {
            "epoch": epoch,
            "train_loss": train_metrics["loss"],
            "train_top1": train_metrics["top1"],
            "train_top5": train_metrics["top5"],
            "val_loss": val_metrics["loss"],
            "val_top1": val_metrics["top1"],
            "val_top5": val_metrics["top5"],
        }
        history.append(row)

        print(
            f"epoch {epoch:03d} | "
            f"train loss {row['train_loss']:.4f}, top1 {row['train_top1']:.4f}, top5 {row['train_top5']:.4f} | "
            f"val loss {row['val_loss']:.4f}, top1 {row['val_top1']:.4f}, top5 {row['val_top5']:.4f}"
        )

        if val_metrics["loss"] < best_val_loss:
            best_val_loss = val_metrics["loss"]
            torch.save(model.state_dict(), best_path)

    save_history(history, output_dir)

    model.load_state_dict(torch.load(best_path, map_location=device))
    test_metrics = run_epoch(model, test_loader, criterion, device)
    (output_dir / "test_metrics.json").write_text(json.dumps(test_metrics, indent=2), encoding="utf-8")
    save_prediction_heatmap(model, test_ds, output_dir, device)

    print("Test metrics:", test_metrics)
    print(f"Saved outputs to: {output_dir}")


if __name__ == "__main__":
    main()

