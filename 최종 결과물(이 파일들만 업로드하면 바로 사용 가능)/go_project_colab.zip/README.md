# Go Move Prediction Term Project

This project fine-tunes and evaluates a deep learning model for predicting the next move in Go from board states extracted from SGF game records.

## Project Workflow

1. Define the problem
2. Select the model
3. Fine-tune / tune the model
4. Evaluate training and test results
5. Visualize results and compare experimental changes

## Current Direction

- Task: next-move prediction on a 19x19 Go board
- Input: board state represented as image-like planes
- Output: probability distribution over 361 board intersections
- Model family: CNN / small residual CNN policy network
- Dataset: CWI Japanese professional Go SGF archive prepared as a custom dataset

## Dataset Status

Downloaded dataset:

```text
data/raw/cwi_go_games.tgz
data/raw/cwi_go_games/games/
```

Current extracted SGF count: about 95,000 games.

## Planned Experiments

- Baseline CNN vs residual CNN
- With vs without board symmetry augmentation
- Different learning rates
- Freeze/unfreeze or partial fine-tuning if a pretrained policy model is used
- Top-1 and Top-5 accuracy comparison

## Prepare a Small Dataset Sample

```powershell
python scripts/prepare_go_dataset.py --input data/raw/cwi_go_games/games --output data/processed/go_moves_sample.npz --max-games 500 --max-positions 100000
```

## Colab Training

Use the Colab guide:

```text
docs/04_colab_training_guide.md
```

The main training script is:

```text
scripts/train_go_policy.py
```

## Minimal Go App

Open this file in a browser:

```text
go_app/index.html
```

It provides a small interactive board with alternating black/white turns, Top-5 move suggestions, and hover preview stones. The current local app uses a lightweight JavaScript policy fallback because trained Colab model weights are not stored in this workspace.

To connect the trained Colab model, run:

```powershell
python go_app/server.py --checkpoint-dir outputs/resnet_aug_200k --port 8000
```

Then open:

```text
http://localhost:8000
```

For Colab, use:

```text
notebooks/go_colab_run_saved_app.ipynb
```

Upload `go_project_colab.zip` and `trained_go_model.zip`, then run all cells. This starts the app without retraining.
