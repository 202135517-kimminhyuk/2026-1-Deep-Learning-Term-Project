# Problem Definition

## Project Title

Go Board Next-Move Prediction Using Deep Learning

## Background

Go is a complex board game played on a 19x19 grid. At each turn, a player chooses one point among hundreds of possible board intersections. Because the board has a strong spatial structure, Go is a suitable domain for convolutional neural networks and transfer learning experiments.

The goal of this project is not to build a professional-level Go engine like AlphaGo. Instead, the goal is to build and tune a deep learning model that learns patterns from actual game records and predicts likely human moves.

## Problem Statement

Given the current Go board state before a move, predict the next move played by the human player.

This is formulated as a multi-class classification problem:

- Input: a 19x19 board state encoded as multiple feature planes
- Output: one of 361 possible board positions
- Label: the actual next move from the SGF game record

Pass moves can be ignored in the first version to keep the task simple, or added later as a 362nd class.

## Why This Problem Is Meaningful

This problem is meaningful for a deep learning term project because:

- The input has a natural 2D spatial structure.
- The output is a probability distribution over many possible classes.
- Data augmentation can be applied using Go board symmetries.
- Model tuning can be tested through learning rate, batch size, augmentation, and architecture changes.
- Evaluation can include not only accuracy but also Top-k accuracy and prediction heatmaps.

## Dataset Definition

The dataset will be created from SGF game records.

For each game:

1. Replay the game move by move.
2. Before each move, save the current board state.
3. Use the next move as the label.
4. Skip illegal, pass, or malformed moves if necessary.

The resulting dataset consists of many `(board_state, next_move)` pairs.

## Input Representation

The initial input representation will use the following planes:

1. Current player's stones
2. Opponent's stones
3. Empty intersections
4. Turn indicator plane

The board state becomes a tensor of shape:

```text
4 x 19 x 19
```

Additional feature planes may be added later:

- Move number
- Liberties
- Previous move location
- Ko position

## Output Representation

The model outputs a vector of length 361.

Each index corresponds to a board coordinate:

```text
index = row * 19 + column
```

The output is converted to probabilities using softmax.

## Evaluation Metrics

Because Go does not always have a single correct move, Top-1 accuracy alone may be too strict. Therefore, the project will report:

- Training loss
- Validation loss
- Top-1 accuracy
- Top-5 accuracy
- Confusion or error examples
- Prediction heatmap for selected board positions

## Expected Limitations

The model is expected to have limited performance because:

- The dataset may be small compared to professional Go AI datasets.
- A single human move is treated as the only correct label, even though many moves can be reasonable.
- The model predicts policy only and does not perform game-tree search.

These limitations are acceptable because the project focuses on hands-on deep learning model tuning and experimental analysis.

