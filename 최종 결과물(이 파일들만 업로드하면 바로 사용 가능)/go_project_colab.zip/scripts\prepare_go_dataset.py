import argparse
import re
from pathlib import Path

import numpy as np


BOARD_SIZE = 19
MOVE_RE = re.compile(r";\s*([BW])\s*\[([^\]]*)\]")
SIZE_RE = re.compile(r"SZ\[([0-9]+)\]")


def sgf_coord_to_rc(coord):
    if not coord or len(coord) < 2:
        return None
    col = ord(coord[0]) - ord("a")
    row = ord(coord[1]) - ord("a")
    if not (0 <= row < BOARD_SIZE and 0 <= col < BOARD_SIZE):
        return None
    return row, col


def neighbors(row, col):
    if row > 0:
        yield row - 1, col
    if row + 1 < BOARD_SIZE:
        yield row + 1, col
    if col > 0:
        yield row, col - 1
    if col + 1 < BOARD_SIZE:
        yield row, col + 1


def group_and_liberties(board, row, col):
    color = board[row, col]
    stack = [(row, col)]
    stones = set()
    liberties = set()

    while stack:
        point = stack.pop()
        if point in stones:
            continue
        stones.add(point)
        for nr, nc in neighbors(*point):
            value = board[nr, nc]
            if value == 0:
                liberties.add((nr, nc))
            elif value == color and (nr, nc) not in stones:
                stack.append((nr, nc))

    return stones, liberties


def play_move(board, color, row, col):
    if board[row, col] != 0:
        return False

    board[row, col] = color
    opponent = -color

    for nr, nc in list(neighbors(row, col)):
        if board[nr, nc] != opponent:
            continue
        stones, liberties = group_and_liberties(board, nr, nc)
        if not liberties:
            for sr, sc in stones:
                board[sr, sc] = 0

    stones, liberties = group_and_liberties(board, row, col)
    if not liberties:
        board[row, col] = 0
        return False

    return True


def encode_board(board, color_to_move):
    current = board == color_to_move
    opponent = board == -color_to_move
    empty = board == 0
    turn = np.full((BOARD_SIZE, BOARD_SIZE), 1 if color_to_move == 1 else 0, dtype=np.uint8)
    return np.stack([current, opponent, empty, turn]).astype(np.uint8)


def parse_sgf_text(text):
    size_match = SIZE_RE.search(text)
    if size_match and int(size_match.group(1)) != BOARD_SIZE:
        return []

    return [(player, sgf_coord_to_rc(coord)) for player, coord in MOVE_RE.findall(text)]


def iter_sgf_files(input_dir):
    yield from Path(input_dir).rglob("*.sgf")


def build_dataset(input_dir, max_games=None, max_positions=None):
    xs = []
    ys = []
    used_games = 0
    skipped_games = 0

    for sgf_path in iter_sgf_files(input_dir):
        if max_games is not None and used_games >= max_games:
            break
        try:
            text = sgf_path.read_text(encoding="utf-8", errors="ignore")
            moves = parse_sgf_text(text)
        except OSError:
            skipped_games += 1
            continue

        if not moves:
            skipped_games += 1
            continue

        board = np.zeros((BOARD_SIZE, BOARD_SIZE), dtype=np.int8)
        game_samples = 0

        for player, point in moves:
            color = 1 if player == "B" else -1
            if point is None:
                continue

            row, col = point
            xs.append(encode_board(board, color))
            ys.append(row * BOARD_SIZE + col)
            game_samples += 1

            if not play_move(board, color, row, col):
                if game_samples:
                    del xs[-game_samples:]
                    del ys[-game_samples:]
                skipped_games += 1
                game_samples = 0
                break

            if max_positions is not None and len(xs) >= max_positions:
                return np.asarray(xs, dtype=np.uint8), np.asarray(ys, dtype=np.int64), used_games + 1, skipped_games

        if game_samples:
            used_games += 1

    return np.asarray(xs, dtype=np.uint8), np.asarray(ys, dtype=np.int64), used_games, skipped_games


def main():
    parser = argparse.ArgumentParser(description="Build a Go next-move dataset from SGF files.")
    parser.add_argument("--input", required=True, help="Directory containing SGF files.")
    parser.add_argument("--output", required=True, help="Output .npz file.")
    parser.add_argument("--max-games", type=int, default=500)
    parser.add_argument("--max-positions", type=int, default=100_000)
    args = parser.parse_args()

    x, y, used_games, skipped_games = build_dataset(
        args.input,
        max_games=args.max_games,
        max_positions=args.max_positions,
    )

    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(
        output,
        x=x,
        y=y,
        board_size=np.asarray([BOARD_SIZE], dtype=np.int64),
        used_games=np.asarray([used_games], dtype=np.int64),
        skipped_games=np.asarray([skipped_games], dtype=np.int64),
    )

    print(f"Saved: {output}")
    print(f"Positions: {len(y)}")
    print(f"Used games: {used_games}")
    print(f"Skipped games: {skipped_games}")
    print(f"X shape: {x.shape}")
    print(f"y shape: {y.shape}")


if __name__ == "__main__":
    main()

