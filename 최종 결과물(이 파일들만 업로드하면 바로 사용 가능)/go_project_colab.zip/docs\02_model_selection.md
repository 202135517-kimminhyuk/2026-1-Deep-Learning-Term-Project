# Model Selection

## Selected Model Family

The selected model family is a convolutional neural network policy model for Go next-move prediction.

This choice is appropriate because a Go board is a 19x19 spatial grid, similar to an image. Local patterns such as connections, captures, eyes, and influence can be learned through convolutional filters. Deeper CNNs or residual CNNs can also combine local patterns into larger strategic features.

## Baseline Model

The first model will be a simple CNN classifier.

Proposed baseline architecture:

```text
Input: 4 x 19 x 19

Conv2D 4 -> 64, kernel size 3, padding 1
BatchNorm
ReLU

Conv2D 64 -> 64, kernel size 3, padding 1
BatchNorm
ReLU

Conv2D 64 -> 64, kernel size 3, padding 1
BatchNorm
ReLU

Flatten
Linear 64*19*19 -> 361
Softmax during evaluation
```

This model is intentionally simple so that it can serve as a clear baseline.

## Main Model

The main model will be a small residual CNN inspired by Go policy networks.

Proposed architecture:

```text
Input: 4 x 19 x 19

Stem:
Conv2D 4 -> 64, kernel size 3, padding 1
BatchNorm
ReLU

Residual Block x N:
Conv2D 64 -> 64, kernel size 3, padding 1
BatchNorm
ReLU
Conv2D 64 -> 64, kernel size 3, padding 1
BatchNorm
Skip connection
ReLU

Policy Head:
Conv2D 64 -> 2, kernel size 1
BatchNorm
ReLU
Flatten
Linear 2*19*19 -> 361
```

The number of residual blocks can be tuned, for example:

- 2 blocks
- 4 blocks
- 6 blocks

## Why CNN / Residual CNN

CNNs are selected because:

- They preserve board geometry.
- They can learn local tactical patterns.
- They are computationally lighter than transformer-based models.
- They support simple and meaningful visualization through policy heatmaps.

Residual CNNs are selected as the main model because:

- Skip connections help train deeper networks.
- Go AI systems commonly use residual policy/value networks.
- Architecture depth can be used as an experimental variable.

## Transfer Learning / Fine-Tuning Strategy

There are two possible strategies.

### Strategy A: Fine-tune a Pretrained Go Policy Model

If a usable pretrained Go policy network is available, we can load the pretrained weights and fine-tune the final policy head or the last few residual blocks on our custom SGF dataset.

This would directly satisfy the transfer learning requirement.

### Strategy B: Pretrain Then Fine-tune Within Our Project

If no pretrained weights are available, we can simulate transfer learning by splitting the dataset:

1. Pretrain the model on a larger mixed SGF dataset.
2. Fine-tune it on a smaller custom subset, such as:
   - games by a selected rank range
   - games by a selected player
   - only opening/middle-game positions

This still demonstrates the idea of transfer learning because the model first learns general Go patterns and then adapts to a narrower target dataset.

## Planned Hyperparameter Tuning

The following variables will be changed and compared:

- Learning rate: `1e-3`, `3e-4`, `1e-4`
- Batch size: `32`, `64`
- Number of residual blocks: `2`, `4`, `6`
- Data augmentation: off vs on
- Dropout: off vs `0.2`

## Planned Visualizations

The report will include:

- Training loss curve
- Validation loss curve
- Top-1 accuracy curve
- Top-5 accuracy curve
- Experiment comparison table
- Heatmap of predicted move probabilities
- Examples of correct and incorrect predictions

## Final Model Choice

The final model will be selected based on validation Top-5 accuracy and stability of training curves, not only Top-1 accuracy.

This is important because Go has multiple reasonable moves in many board states, so Top-5 accuracy better reflects whether the model learned meaningful move candidates.

