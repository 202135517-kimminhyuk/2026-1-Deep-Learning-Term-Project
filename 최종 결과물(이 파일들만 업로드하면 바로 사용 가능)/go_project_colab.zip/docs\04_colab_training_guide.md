# Colab Training Guide

This guide runs the Go next-move prediction project on Google Colab.

## 1. Runtime Setting

In Colab:

```text
Runtime -> Change runtime type -> T4 GPU
```

PyTorch is already installed in most Colab runtimes, so no additional deep learning installation is usually required.

## 2. Upload Project Code

Upload this project folder to Google Drive, excluding the `data/` folder.

Recommended Drive path:

```text
MyDrive/Term Project
```

Then run this in Colab:

```python
from google.colab import drive
drive.mount("/content/drive")
```

```python
%cd "/content/drive/MyDrive/Term Project"
```

If your folder name is different, change the `%cd` path.

## 3. Download SGF Dataset in Colab

```python
!mkdir -p data/raw/cwi_go_games
!wget -O data/raw/cwi_go_games.tgz https://homepages.cwi.nl/~aeb/go/games/games.tgz
!tar -xzf data/raw/cwi_go_games.tgz -C data/raw/cwi_go_games
```

The extracted SGF files should be under:

```text
data/raw/cwi_go_games/games/
```

## 4. Build a Debug Dataset

Start small to verify that the pipeline works.

```python
!python scripts/prepare_go_dataset.py \
  --input data/raw/cwi_go_games/games \
  --output data/processed/go_moves_debug.npz \
  --max-games 200 \
  --max-positions 30000
```

Expected output shape:

```text
X shape: (number_of_positions, 4, 19, 19)
y shape: (number_of_positions,)
```

## 5. Train Baseline CNN

```python
!python scripts/train_go_policy.py \
  --data data/processed/go_moves_debug.npz \
  --output-dir outputs/baseline_debug \
  --model baseline \
  --epochs 5 \
  --batch-size 256 \
  --lr 0.001 \
  --channels 64
```

## 6. Train Residual CNN with Augmentation

```python
!python scripts/train_go_policy.py \
  --data data/processed/go_moves_debug.npz \
  --output-dir outputs/resnet_aug_debug \
  --model resnet \
  --epochs 5 \
  --batch-size 256 \
  --lr 0.0003 \
  --channels 64 \
  --blocks 4 \
  --augment
```

## 7. Create a Larger Dataset for Final Experiments

If the debug run works, create a larger dataset.

```python
!python scripts/prepare_go_dataset.py \
  --input data/raw/cwi_go_games/games \
  --output data/processed/go_moves_200k.npz \
  --max-games 1000 \
  --max-positions 200000
```

Then train final models:

```python
!python scripts/train_go_policy.py \
  --data data/processed/go_moves_200k.npz \
  --output-dir outputs/baseline_lr1e3 \
  --model baseline \
  --epochs 10 \
  --batch-size 256 \
  --lr 0.001 \
  --channels 64
```

```python
!python scripts/train_go_policy.py \
  --data data/processed/go_moves_200k.npz \
  --output-dir outputs/resnet_aug_lr3e4 \
  --model resnet \
  --epochs 10 \
  --batch-size 256 \
  --lr 0.0003 \
  --channels 64 \
  --blocks 4 \
  --augment
```

```python
!python scripts/train_go_policy.py \
  --data data/processed/go_moves_200k.npz \
  --output-dir outputs/resnet_aug_lr1e4 \
  --model resnet \
  --epochs 10 \
  --batch-size 256 \
  --lr 0.0001 \
  --channels 64 \
  --blocks 4 \
  --augment
```

## 8. Output Files

Each experiment folder saves:

```text
config.json
history.csv
loss_curve.png
accuracy_curve.png
prediction_heatmap.png
test_metrics.json
best_model.pt
```

The report should use:

- `history.csv`
- `loss_curve.png`
- `accuracy_curve.png`
- `prediction_heatmap.png`
- `test_metrics.json`

## 9. Suggested Experiment Table

| Experiment | Model | Augmentation | Learning Rate | Blocks | Expected Purpose |
|---|---|---:|---:|---:|---|
| Baseline | CNN | No | 1e-3 | - | Simple reference model |
| ResNet Aug | Residual CNN | Yes | 3e-4 | 4 | Main model |
| ResNet LR Low | Residual CNN | Yes | 1e-4 | 4 | Learning-rate comparison |

