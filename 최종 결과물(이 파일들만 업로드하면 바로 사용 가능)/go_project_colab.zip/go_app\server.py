import argparse
import json
from pathlib import Path

import numpy as np
import torch
from flask import Flask, jsonify, request, send_from_directory

import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT / "scripts") not in sys.path:
    sys.path.append(str(ROOT / "scripts"))

from train_go_policy import BOARD_SIZE, NUM_MOVES, build_model  # noqa: E402


EMPTY = 0
BLACK = 1
WHITE = -1


def neighbors(row, col):
    if row > 0:
        yield row - 1, col
    if row + 1 < BOARD_SIZE:
        yield row + 1, col
    if col > 0:
        yield row, col - 1
    if col + 1 < BOARD_SIZE:
        yield row, col + 1


def group_and_liberties(board, row, col):
    color = board[row][col]
    stack = [(row, col)]
    stones = set()
    liberties = set()

    while stack:
        point = stack.pop()
        if point in stones:
            continue
        stones.add(point)
        for nr, nc in neighbors(*point):
            value = board[nr][nc]
            if value == EMPTY:
                liberties.add((nr, nc))
            elif value == color and (nr, nc) not in stones:
                stack.append((nr, nc))

    return stones, liberties


def try_move(board, row, col, color):
    if board[row][col] != EMPTY:
        return None

    next_board = [line[:] for line in board]
    next_board[row][col] = color
    opponent = -color

    for nr, nc in neighbors(row, col):
        if next_board[nr][nc] != opponent:
            continue
        stones, liberties = group_and_liberties(next_board, nr, nc)
        if not liberties:
            for sr, sc in stones:
                next_board[sr][sc] = EMPTY

    _, liberties = group_and_liberties(next_board, row, col)
    if not liberties:
        return None
    return next_board


def encode_board(board, color):
    arr = np.asarray(board, dtype=np.int8)
    current = arr == color
    opponent = arr == -color
    empty = arr == EMPTY
    turn = np.full((BOARD_SIZE, BOARD_SIZE), 1 if color == BLACK else 0, dtype=np.uint8)
    x = np.stack([current, opponent, empty, turn]).astype(np.float32)
    return torch.from_numpy(x).unsqueeze(0)


def load_model(checkpoint_dir):
    checkpoint_dir = Path(checkpoint_dir)
    config_path = checkpoint_dir / "config.json"
    model_path = checkpoint_dir / "best_model.pt"
    if not config_path.exists() or not model_path.exists():
        raise FileNotFoundError(f"Missing config.json or best_model.pt in {checkpoint_dir}")

    config = json.loads(config_path.read_text(encoding="utf-8"))

    class Args:
        pass

    args = Args()
    args.model = config.get("model", "resnet")
    args.channels = int(config.get("channels", 64))
    args.blocks = int(config.get("blocks", 4))
    args.dropout = float(config.get("dropout", 0.0))

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = build_model(args).to(device)
    state = torch.load(model_path, map_location=device)
    model.load_state_dict(state)
    model.eval()
    return model, device


def create_app(checkpoint_dir):
    app = Flask(__name__, static_folder=str(Path(__file__).resolve().parent))
    model, device = load_model(checkpoint_dir)

    @app.route("/")
    def index():
        return send_from_directory(app.static_folder, "index.html")

    @app.route("/<path:path>")
    def static_files(path):
        return send_from_directory(app.static_folder, path)

    @app.route("/api/recommend", methods=["POST"])
    def recommend():
        data = request.get_json(force=True)
        board = data["board"]
        color = int(data["current"])

        x = encode_board(board, color).to(device)
        with torch.no_grad():
            logits = model(x)[0].detach().cpu().numpy()

        ranked = np.argsort(logits)[::-1]
        moves = []
        for idx in ranked:
            row = int(idx // BOARD_SIZE)
            col = int(idx % BOARD_SIZE)
            if try_move(board, row, col, color) is None:
                continue
            moves.append({"row": row, "col": col, "score": float(logits[idx])})
            if len(moves) == 5:
                break

        return jsonify({"moves": moves})

    return app


def main():
    parser = argparse.ArgumentParser(description="Serve the Go app with a trained PyTorch model.")
    parser.add_argument("--checkpoint-dir", default="outputs/resnet_aug_200k")
    parser.add_argument("--host", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=8000)
    args = parser.parse_args()

    app = create_app(args.checkpoint_dir)
    app.run(host=args.host, port=args.port)


if __name__ == "__main__":
    main()

